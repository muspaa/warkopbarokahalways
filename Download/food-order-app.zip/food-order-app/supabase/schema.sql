-- Jalankan ini di Supabase: SQL Editor > New Query > paste > Run

-- Tabel menu
create table menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price integer not null,
  image_url text,
  is_available boolean default true,
  created_at timestamp with time zone default now()
);

-- Tabel pesanan
create table orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  table_number text,
  notes text,
  status text default 'pending', -- pending, diproses, selesai, dibatalkan
  total integer not null default 0,
  created_at timestamp with time zone default now()
);

-- Detail item dalam satu pesanan
create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references orders(id) on delete cascade,
  menu_item_id uuid references menu_items(id),
  menu_name text not null,
  price integer not null,
  quantity integer not null default 1
);

-- Aktifkan Row Level Security
alter table menu_items enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

-- Semua orang boleh BACA menu (untuk halaman pemesanan publik)
create policy "Menu bisa dibaca semua orang"
  on menu_items for select
  using (true);

-- Semua orang boleh BUAT pesanan (customer pesan tanpa login)
create policy "Siapapun bisa membuat order"
  on orders for insert
  with check (true);

create policy "Siapapun bisa membuat order item"
  on order_items for insert
  with check (true);

-- Hanya admin (user yang login) yang boleh ubah/hapus menu
create policy "Admin bisa kelola menu"
  on menu_items for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

-- Hanya admin yang boleh baca & update semua order
create policy "Admin bisa baca semua order"
  on orders for select
  using (auth.role() = 'authenticated');

create policy "Admin bisa update order"
  on orders for update
  using (auth.role() = 'authenticated');

create policy "Admin bisa baca order items"
  on order_items for select
  using (auth.role() = 'authenticated');
