# Panduan Membuat Website Pesan Menu Makanan (dari HP)

Stack: **Next.js** (kode website) + **Supabase** (database & login admin) + **Vercel** (hosting/publish) + **Cloudflare** (opsional, untuk domain sendiri nanti).

Semua langkah di bawah bisa dilakukan lewat browser HP (Chrome/Safari). Tidak perlu install apa-apa di HP.

---

## BAGIAN 1 — Siapkan akun (10 menit)

1. Buka https://github.com dari HP, daftar akun gratis (kalau belum punya).
2. Buka https://supabase.com, klik **Start your project**, daftar/login pakai akun GitHub.
3. Buka https://vercel.com, daftar/login juga pakai akun GitHub yang sama.

---

## BAGIAN 2 — Buat Database di Supabase

1. Di dashboard Supabase, klik **New Project**.
2. Isi nama project (bebas), buat password database (simpan baik-baik), pilih region terdekat (Singapore), klik **Create new project**. Tunggu 1-2 menit sampai selesai.
3. Setelah project jadi, di menu kiri klik **SQL Editor** → **New query**.
4. Buka file `supabase/schema.sql` yang saya sediakan, salin semua isinya, tempel ke SQL Editor, lalu klik **Run**.
   - Ini akan membuat 3 tabel: `menu_items` (menu), `orders` (pesanan), `order_items` (detail pesanan).
5. Buat akun admin: di menu kiri klik **Authentication** → **Users** → **Add user** → **Create new user**. Isi email & password Anda sendiri (ini yang dipakai login ke dashboard admin nanti). Centang "Auto Confirm User".
6. Ambil kunci API: klik **Project Settings** (ikon gerigi) → **API**. Catat/salin dua hal ini:
   - **Project URL**
   - **anon public key**

---

## BAGIAN 3 — Upload Kode ke GitHub

1. Buka https://github.com/new dari HP.
2. Beri nama repository, misal `menu-makanan`, set ke **Public** atau **Private**, klik **Create repository**.
3. Di halaman repo kosong, klik **uploading an existing file**.
4. Upload SEMUA file & folder dari project ini (yang saya berikan) — pertahankan struktur foldernya (app/, lib/, supabase/, package.json, dll).
   - Tips dari HP: kalau GitHub susah upload folder, extract dulu zip-nya di aplikasi File Manager HP, lalu upload file satu-satu sesuai folder aslinya, atau gunakan aplikasi seperti "Working Copy"/"Termux" jika mau lebih mudah. Cara termudah: gunakan browser desktop mode di Chrome HP agar tampilan upload GitHub lebih leluasa.
5. Klik **Commit changes**.

---

## BAGIAN 4 — Deploy ke Vercel

1. Buka https://vercel.com/new.
2. Pilih **Import Git Repository**, cari repo `menu-makanan` yang tadi dibuat, klik **Import**.
3. Di bagian **Environment Variables**, tambahkan dua variabel ini (ambil dari Bagian 2 langkah 6):
   - `NEXT_PUBLIC_SUPABASE_URL` = Project URL Supabase Anda
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = anon public key Supabase Anda
4. Klik **Deploy**. Tunggu 1-2 menit.
5. Setelah selesai, Vercel akan memberi link seperti `menu-makanan.vercel.app` — ini website Anda yang sudah LIVE.

---

## BAGIAN 5 — Coba Website

1. Buka link Vercel Anda → ini halaman pemesanan customer. Tambahkan menu dulu lewat dashboard admin (langkah berikut) supaya ada isinya.
2. Buka `namawebsite.vercel.app/admin/login` → login pakai email/password admin yang dibuat di Bagian 2 langkah 5.
3. Di dashboard admin:
   - Tab **Menu**: tambah menu makanan (nama, harga, deskripsi, gambar via URL).
   - Tab **Pesanan**: lihat pesanan masuk dan ubah status (pending → diproses → selesai).

---

## BAGIAN 6 — (Opsional) Pakai Domain Sendiri via Cloudflare

1. Beli domain (di Cloudflare Registrar, Niagahoster, dll).
2. Di Cloudflare dashboard, tambahkan domain Anda, ikuti instruksi untuk arahkan nameserver ke Cloudflare.
3. Di Vercel, buka project → **Settings** → **Domains** → tambahkan domain Anda.
4. Vercel akan kasih instruksi record DNS (biasanya CNAME) — masukkan record itu di Cloudflare DNS settings.
5. Tunggu beberapa menit sampai propagasi selesai, domain Anda aktif.

---

## Cara Update Website Nanti

- Setiap kali Anda edit file di GitHub (langsung di web GitHub, klik ikon pensil pada file), Vercel otomatis build ulang dan publish versi terbaru dalam ~1 menit. Tidak perlu deploy manual lagi.

## Kalau Ada Error

- **Menu tidak muncul**: cek apakah SQL schema sudah dijalankan dan ada data menu yang `is_available = true`.
- **Login admin gagal**: pastikan user sudah dibuat di Supabase Authentication dan "Auto Confirm" dicentang.
- **Environment variable salah**: cek lagi NEXT_PUBLIC_SUPABASE_URL dan ANON_KEY di Vercel Settings → Environment Variables, lalu klik **Redeploy**.
