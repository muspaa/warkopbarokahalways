"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

const STATUS_OPTIONS = ["pending", "diproses", "selesai", "dibatalkan"];

export default function AdminDashboard() {
  const router = useRouter();
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [tab, setTab] = useState("orders");

  // Menu state
  const [menu, setMenu] = useState([]);
  const [form, setForm] = useState({ name: "", description: "", price: "", image_url: "" });
  const [editingId, setEditingId] = useState(null);

  // Orders state
  const [orders, setOrders] = useState([]);
  const [orderItemsMap, setOrderItemsMap] = useState({});

  useEffect(() => {
    checkAuth();
  }, []);

  async function checkAuth() {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      router.push("/admin/login");
      return;
    }
    setCheckingAuth(false);
    loadMenu();
    loadOrders();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/admin/login");
  }

  // ---- MENU ----
  async function loadMenu() {
    const { data } = await supabase
      .from("menu_items")
      .select("*")
      .order("created_at", { ascending: false });
    setMenu(data || []);
  }

  async function saveMenuItem(e) {
    e.preventDefault();
    const payload = {
      name: form.name,
      description: form.description,
      price: parseInt(form.price || "0", 10),
      image_url: form.image_url,
    };

    if (editingId) {
      await supabase.from("menu_items").update(payload).eq("id", editingId);
    } else {
      await supabase.from("menu_items").insert(payload);
    }

    setForm({ name: "", description: "", price: "", image_url: "" });
    setEditingId(null);
    loadMenu();
  }

  function editItem(item) {
    setEditingId(item.id);
    setForm({
      name: item.name,
      description: item.description || "",
      price: String(item.price),
      image_url: item.image_url || "",
    });
    setTab("menu");
  }

  async function deleteItem(id) {
    if (!confirm("Hapus menu ini?")) return;
    await supabase.from("menu_items").delete().eq("id", id);
    loadMenu();
  }

  async function toggleAvailable(item) {
    await supabase
      .from("menu_items")
      .update({ is_available: !item.is_available })
      .eq("id", item.id);
    loadMenu();
  }

  // ---- ORDERS ----
  async function loadOrders() {
    const { data } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    setOrders(data || []);
  }

  async function loadOrderItems(orderId) {
    if (orderItemsMap[orderId]) {
      // toggle off
      setOrderItemsMap((prev) => {
        const copy = { ...prev };
        delete copy[orderId];
        return copy;
      });
      return;
    }
    const { data } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", orderId);
    setOrderItemsMap((prev) => ({ ...prev, [orderId]: data || [] }));
  }

  async function updateStatus(orderId, status) {
    await supabase.from("orders").update({ status }).eq("id", orderId);
    loadOrders();
  }

  if (checkingAuth) return <p className="p-6">Memuat...</p>;

  return (
    <div className="max-w-2xl mx-auto p-4 pb-20">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Dashboard Admin</h1>
        <button onClick={handleLogout} className="text-sm text-red-600">
          Keluar
        </button>
      </div>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setTab("orders")}
          className={`px-4 py-2 rounded-lg font-medium ${
            tab === "orders" ? "bg-black text-white" : "bg-gray-200"
          }`}
        >
          Pesanan
        </button>
        <button
          onClick={() => setTab("menu")}
          className={`px-4 py-2 rounded-lg font-medium ${
            tab === "menu" ? "bg-black text-white" : "bg-gray-200"
          }`}
        >
          Menu
        </button>
      </div>

      {tab === "orders" && (
        <div className="space-y-3">
          {orders.length === 0 && (
            <p className="text-gray-500">Belum ada pesanan.</p>
          )}
          {orders.map((order) => (
            <div key={order.id} className="bg-white rounded-xl p-3 shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold">{order.customer_name}</p>
                  <p className="text-sm text-gray-500">
                    Meja: {order.table_number || "-"} &middot;{" "}
                    {new Date(order.created_at).toLocaleString("id-ID")}
                  </p>
                  {order.notes && (
                    <p className="text-sm text-gray-500">Catatan: {order.notes}</p>
                  )}
                </div>
                <p className="font-semibold">
                  Rp {order.total.toLocaleString("id-ID")}
                </p>
              </div>

              <div className="flex items-center justify-between mt-2">
                <button
                  onClick={() => loadOrderItems(order.id)}
                  className="text-sm text-blue-600"
                >
                  {orderItemsMap[order.id] ? "Sembunyikan item" : "Lihat item"}
                </button>
                <select
                  value={order.status}
                  onChange={(e) => updateStatus(order.id, e.target.value)}
                  className="border rounded-lg p-1 text-sm"
                >
                  {STATUS_OPTIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              {orderItemsMap[order.id] && (
                <ul className="mt-2 text-sm text-gray-600 border-t pt-2 space-y-1">
                  {orderItemsMap[order.id].map((it) => (
                    <li key={it.id}>
                      {it.quantity}x {it.menu_name} — Rp{" "}
                      {(it.price * it.quantity).toLocaleString("id-ID")}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === "menu" && (
        <div>
          <form
            onSubmit={saveMenuItem}
            className="bg-white rounded-xl p-3 shadow-sm space-y-2 mb-4"
          >
            <p className="font-semibold">
              {editingId ? "Edit Menu" : "Tambah Menu Baru"}
            </p>
            <input
              className="w-full border rounded-lg p-2"
              placeholder="Nama menu"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
            <input
              className="w-full border rounded-lg p-2"
              placeholder="Deskripsi (opsional)"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
            <input
              type="number"
              className="w-full border rounded-lg p-2"
              placeholder="Harga (contoh: 15000)"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              required
            />
            <input
              className="w-full border rounded-lg p-2"
              placeholder="URL gambar (opsional)"
              value={form.image_url}
              onChange={(e) => setForm({ ...form, image_url: e.target.value })}
            />
            <div className="flex gap-2">
              <button
                type="submit"
                className="flex-1 bg-black text-white py-2 rounded-lg font-semibold"
              >
                {editingId ? "Simpan Perubahan" : "Tambah Menu"}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(null);
                    setForm({ name: "", description: "", price: "", image_url: "" });
                  }}
                  className="px-4 bg-gray-200 rounded-lg"
                >
                  Batal
                </button>
              )}
            </div>
          </form>

          <div className="space-y-2">
            {menu.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl p-3 shadow-sm flex justify-between items-center"
              >
                <div>
                  <p className="font-semibold">{item.name}</p>
                  <p className="text-sm text-gray-500">
                    Rp {item.price.toLocaleString("id-ID")} &middot;{" "}
                    {item.is_available ? "Tersedia" : "Nonaktif"}
                  </p>
                </div>
                <div className="flex gap-2 text-sm">
                  <button
                    onClick={() => toggleAvailable(item)}
                    className="text-blue-600"
                  >
                    {item.is_available ? "Nonaktifkan" : "Aktifkan"}
                  </button>
                  <button onClick={() => editItem(item)} className="text-gray-700">
                    Edit
                  </button>
                  <button
                    onClick={() => deleteItem(item.id)}
                    className="text-red-600"
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
