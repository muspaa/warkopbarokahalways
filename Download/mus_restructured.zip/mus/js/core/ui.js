document.addEventListener('visibilitychange', function () {
  document.documentElement.classList.toggle('tab-hidden', document.hidden);
});
setTimeout(function(){var sp=document.getElementById('splash-screen');if(sp&&!sp.classList.contains('hide'))sp.classList.add('hide');},2200);
