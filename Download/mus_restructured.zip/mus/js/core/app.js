/* NanzMusify application shell: navigation, routing, lifecycle. */
var App = (function () {
    var current = 'home';
    var views = ['home','search','library','offline','liked','dev'];

    function gidLocal(id){ return document.getElementById(id); }
    function hideViews(){
        views.forEach(function(name){
            var el=gidLocal('view-'+name); if(el) el.style.display='none';
        });
    }
    function ensureNav(){
        var nav=gidLocal('nav-container'); if(!nav) return;
        nav.innerHTML = `
        <nav id="bottom-nav" class="fixed bottom-0 left-0 right-0 z-[150] border-t border-white/10 bg-[#0b0c10]/90 backdrop-blur-2xl pb-safe">
          <div class="max-w-xl mx-auto h-[72px] grid grid-cols-5 items-center px-2">
            ${button('home','house','Home')}
            ${button('search','search','Cari')}
            ${button('library','library','Library')}
            ${button('liked','heart','Disukai')}
            ${button('dev','user','Profil')}
          </div>
        </nav>`;
        if(window.lucide && lucide.createIcons) lucide.createIcons();
    }
    function button(name,icon,label){
        return '<button data-nav="'+name+'" onclick="App.switch(\''+name+'\')" class="nav-item flex flex-col items-center justify-center gap-1 py-2 rounded-xl text-[10px] font-semibold text-white/55 transition-all active:scale-95" aria-label="'+label+'"><i data-lucide="'+icon+'" class="w-5 h-5"></i><span>'+label+'</span></button>';
    }
    function updateNav(){
        document.querySelectorAll('[data-nav]').forEach(function(btn){
            var active=btn.getAttribute('data-nav')===current;
            btn.classList.toggle('text-white',active); btn.classList.toggle('bg-white/10',active);
            btn.classList.toggle('text-white/55',!active);
        });
    }
    function renderOffline(){
        var el=gidLocal('view-offline'); if(!el) return;
        var songs=typeof getOfflineSongs==='function'?getOfflineSongs():[];
        if(!songs.length){
            el.innerHTML='<div class="pt-12 px-5 text-center"><div class="w-20 h-20 mx-auto rounded-full bg-white/10 flex items-center justify-center mb-4"><i data-lucide="wifi-off" class="w-9 h-9 text-white/60"></i></div><h1 class="text-2xl font-black text-white">Lagu Offline</h1><p class="text-white/60 text-sm mt-2">Belum ada lagu yang tersimpan untuk mode offline.</p></div>';
        } else {
            var rows=songs.map(function(s,i){return '<button onclick="PK(\'offline\','+i+')" class="w-full flex items-center gap-3 p-3 rounded-2xl bg-white/[.05] border border-white/10 text-left active:scale-[.99]"><img src="'+(s.cover||FI)+'" class="w-14 h-14 rounded-xl object-cover" onerror="this.src=\''+FI+'\'"><span class="min-w-0 flex-1"><b class="block truncate text-sm text-white">'+es(s.title)+'</b><small class="block truncate text-white/60 mt-1">'+es(s.artist)+'</small></span><i data-lucide="play" class="w-5 h-5 text-white/70"></i></button>';}).join('');
            el.innerHTML='<div class="pt-8 px-4"><h1 class="text-3xl font-black text-white">Lagu Offline</h1><p class="text-white/60 text-xs mt-1 mb-5">'+songs.length+' lagu tersimpan</p><div class="space-y-2">'+rows+'</div></div>';
        }
        if(window.lucide&&lucide.createIcons)lucide.createIcons();
    }
    function switchView(name, push){
        if(views.indexOf(name)<0) name='home';
        current=name; if(typeof S!=='undefined') S.at=name;
        hideViews(); var el=gidLocal('view-'+name); if(el) el.style.display='block';
        if(name==='home'){ if(typeof Home!=='undefined') Home.render(); }
        else if(name==='search'){ if(typeof Search!=='undefined'){Search.render();Search.onShow&&Search.onShow();} }
        else if(name==='library'){ if(typeof Library!=='undefined') Library.render(); }
        else if(name==='liked'){ if(typeof Liked!=='undefined') Liked.render(); }
        else if(name==='dev'){ if(typeof Profile!=='undefined') Profile.render(); }
        else if(name==='offline'){ renderOffline(); }
        updateNav();
        if(push){ var path=name==='home'?'/':'/'+name; if(location.pathname!==path) history.pushState({appView:name},'',path); }
        var main=gidLocal('main-area'); if(main) main.scrollTop=0;
    }
    function route(){
        var p=location.pathname;
        var m=p.match(/^\/play\/([^/]+)/); if(m){
            switchView('home',false);
            var vid=decodeURIComponent(m[1]);
            setTimeout(function(){
                if(typeof S!=='undefined' && S.ct && (S.ct.videoId===vid || S.ct.id===vid)) return;
                fetch(API.search+'?q='+encodeURIComponent(vid)).then(function(r){return r.json();}).then(function(d){
                    var list=Array.isArray(d)?d:(d&&Array.isArray(d.result)?d.result:(d&&Array.isArray(d.data)?d.data:[]));
                    var track=list.find(function(t){return t && (t.videoId===vid || t.id===vid);}) || list[0];
                    if(track && typeof PK==='function'){ S.pl=[track]; S.pi=0; PK('home',0); }
                }).catch(function(){ });
            },0);
            return;
        }
        var am=p.match(/^\/artist\/([^/]+)/); if(am && typeof Artist!=='undefined'){ switchView('home',false); setTimeout(function(){Artist.open(decodeURIComponent(am[1]));},0); return; }
        var alb=p.match(/^\/album\/([^/]+)/); if(alb && typeof Album!=='undefined'){ switchView('home',false); setTimeout(function(){Album.open(decodeURIComponent(alb[1]));},0); return; }
        var pl=p.match(/^\/playlist\/([^/]+)/); if(pl && typeof Library!=='undefined'){ switchView('library',false); setTimeout(function(){Library.open(decodeURIComponent(pl[1]));},0); return; }
        var name=p.replace(/^\//,'').split('/')[0]; switchView(views.indexOf(name)>=0?name:'home',false);
    }
    function init(){
        ensureNav();
        if(typeof MP!=='undefined'&&MP.init)MP.init();
        if(typeof FullPlayer!=='undefined'&&FullPlayer.init)FullPlayer.init();
        if(typeof Artist!=='undefined'&&Artist.init)Artist.init();
        if(typeof Album!=='undefined'&&Album.init)Album.init();
        window.addEventListener('popstate',route);
        window.addEventListener('online',function(){var b=gidLocal('pwa-offline-banner');if(b)b.classList.add('hidden');});
        window.addEventListener('offline',function(){var b=gidLocal('pwa-offline-banner');if(b)b.classList.remove('hidden');});
        route();
        setTimeout(function(){var sp=gidLocal('splash-screen');if(sp)sp.classList.add('hide');},250);
    }
    return {init:init,switch:function(name){switchView(name,true);},renderActive:function(){switchView(current,false);},renderLiked:function(){if(typeof Liked!=='undefined')Liked.render();},get current(){return current;}};
})();

document.addEventListener('DOMContentLoaded', function(){ App.init(); });
