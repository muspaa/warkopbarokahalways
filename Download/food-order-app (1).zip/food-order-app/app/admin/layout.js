export const metadata = {
  title: "Admin - Menu Makanan",
};

export default function AdminLayout({ children }) {
  return <div className="min-h-screen bg-gray-50">{children}</div>;
}
