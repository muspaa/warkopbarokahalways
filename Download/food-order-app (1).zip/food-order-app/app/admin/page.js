"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

const STATUS_OPTIONS = ["pending", "diproses", "selesai", "dibatalkan"];
const STATUS_COLOR = {
  pending: "bg-yellow-100 text-yellow-800",
  diproses: "bg-blue-100 text-blue-800",
  selesai: "bg-green-100 text-green-800",
  dibatalkan: "bg-red-100 text-red-800",
};

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "dapur", label: "Dapur" },
  { key: "meja", label: "Meja & QR" },
  { key: "riwayat", label: "Riwayat" },
  { key: "pengeluaran", label: "Pengeluaran" },
  { key: "menu", label: "Menu" },
];

function formatRp(n) {
  return "Rp " + (n || 0).toLocaleString("id-ID");
}

function isToday(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [tab, setTab] = useState("overview");
  const [siteUrl, setSiteUrl] = useState("");

  // Global data
  const [menu, setMenu] = useState([]);
  const [orders, setOrders] = useState([]);
  const [orderItemsMap, setOrderItemsMap] = useState({});
  const [tables, setTables] = useState([]);
  const [expenses, setExpenses] = useState([]);

  // Menu form
  const [form, setForm] = useState({ name: "", description: "", price: "", image_url: "" });
  const [editingId, setEditingId] = useState(null);

  // Table form
  const [newTableName, setNewTableName] = useState("");

  // Expense form
  const [expenseForm, setExpenseForm] = useState({ description: "", amount: "", expense_date: "" });

  useEffect(() => {
    checkAuth();
    if (typeof window !== "undefined") {
      setSiteUrl(window.location.origin);
    }
  }, []);

  async function checkAuth() {
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      router.push("/admin/login");
      return;
    }
    setCheckingAuth(false);
    loadAll();
  }

  function loadAll() {
    loadMenu();
    loadOrders();
    loadTables();
    loadExpenses();
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/admin/login");
  }

  // ---- MENU ----
  async function loadMenu() {
    const { data } = await supabase
      .from("menu_items")
      .select("*")
      .order("created_at", { ascending: false });
    setMenu(data || []);
  }

  async function saveMenuItem(e) {
    e.preventDefault();
    const payload = {
      name: form.name,
      description: form.description,
      price: parseInt(form.price || "0", 10),
      image_url: form.image_url,
    };
    if (editingId) {
      await supabase.from("menu_items").update(payload).eq("id", editingId);
    } else {
      await supabase.from("menu_items").insert(payload);
    }
    setForm({ name: "", description: "", price: "", image_url: "" });
    setEditingId(null);
    loadMenu();
  }

  function editItem(item) {
    setEditingId(item.id);
    setForm({
      name: item.name,
      description: item.description || "",
      price: String(item.price),
      image_url: item.image_url || "",
    });
    setTab("menu");
  }

  async function deleteItem(id) {
    if (!confirm("Hapus menu ini?")) return;
    await supabase.from("menu_items").delete().eq("id", id);
    loadMenu();
  }

  async function toggleAvailable(item) {
    await supabase
      .from("menu_items")
      .update({ is_available: !item.is_available })
      .eq("id", item.id);
    loadMenu();
  }

  // ---- ORDERS ----
  async function loadOrders() {
    const { data } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    setOrders(data || []);
  }

  async function loadOrderItems(orderId) {
    if (orderItemsMap[orderId]) {
      setOrderItemsMap((prev) => {
        const copy = { ...prev };
        delete copy[orderId];
        return copy;
      });
      return;
    }
    const { data } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", orderId);
    setOrderItemsMap((prev) => ({ ...prev, [orderId]: data || [] }));
  }

  async function updateStatus(orderId, status) {
    await supabase.from("orders").update({ status }).eq("id", orderId);
    loadOrders();
  }

  // ---- TABLES ----
  async function loadTables() {
    const { data } = await supabase
      .from("tables")
      .select("*")
      .order("created_at", { ascending: true });
    setTables(data || []);
  }

  async function addTable(e) {
    e.preventDefault();
    if (!newTableName.trim()) return;
    await supabase.from("tables").insert({ name: newTableName });
    setNewTableName("");
    loadTables();
  }

  async function deleteTable(id) {
    if (!confirm("Hapus meja ini?")) return;
    await supabase.from("tables").delete().eq("id", id);
    loadTables();
  }

  // ---- EXPENSES ----
  async function loadExpenses() {
    const { data } = await supabase
      .from("expenses")
      .select("*")
      .order("expense_date", { ascending: false });
    setExpenses(data || []);
  }

  async function addExpense(e) {
    e.preventDefault();
    if (!expenseForm.description.trim() || !expenseForm.amount) return;
    await supabase.from("expenses").insert({
      description: expenseForm.description,
      amount: parseInt(expenseForm.amount, 10),
      expense_date: expenseForm.expense_date || new Date().toISOString().slice(0, 10),
    });
    setExpenseForm({ description: "", amount: "", expense_date: "" });
    loadExpenses();
  }

  async function deleteExpense(id) {
    if (!confirm("Hapus catatan pengeluaran ini?")) return;
    await supabase.from("expenses").delete().eq("id", id);
    loadExpenses();
  }

  if (checkingAuth) return <p className="p-6">Memuat...</p>;

  // ---- Derived stats ----
  const todayOrders = orders.filter((o) => isToday(o.created_at));
  const todayRevenue = todayOrders
    .filter((o) => o.status !== "dibatalkan")
    .reduce((sum, o) => sum + o.total, 0);
  const todayExpenseTotal = expenses
    .filter((e) => isToday(e.expense_date))
    .reduce((sum, e) => sum + e.amount, 0);
  const pendingCount = orders.filter((o) => o.status === "pending").length;
  const diprosesCount = orders.filter((o) => o.status === "diproses").length;
  const kitchenOrders = orders.filter(
    (o) => o.status === "pending" || o.status === "diproses"
  );
  const monthExpenseTotal = expenses
    .filter((e) => {
      const d = new Date(e.expense_date);
      const now = new Date();
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    })
    .reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="max-w-3xl mx-auto pb-24">
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="flex justify-between items-center px-4 py-3">
          <h1 className="text-xl font-bold">Dashboard Admin</h1>
          <button onClick={handleLogout} className="text-sm text-red-600 font-medium">
            Keluar
          </button>
        </div>
        <div className="flex overflow-x-auto gap-1 px-4 pb-2 no-scrollbar">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-full text-sm font-medium ${
                tab === t.key ? "bg-black text-white" : "bg-gray-100 text-gray-700"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4">
        {/* ---------------- OVERVIEW ---------------- */}
        {tab === "overview" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard label="Pesanan Hari Ini" value={todayOrders.length} />
              <StatCard label="Pendapatan Hari Ini" value={formatRp(todayRevenue)} />
              <StatCard label="Menunggu Diproses" value={pendingCount} highlight />
              <StatCard label="Sedang Diproses" value={diprosesCount} />
              <StatCard label="Pengeluaran Hari Ini" value={formatRp(todayExpenseTotal)} />
              <StatCard label="Pengeluaran Bulan Ini" value={formatRp(monthExpenseTotal)} />
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="font-semibold mb-2">Estimasi Untung Hari Ini</p>
              <p className="text-2xl font-bold">
                {formatRp(todayRevenue - todayExpenseTotal)}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                Pendapatan hari ini dikurangi pengeluaran hari ini
              </p>
            </div>

            <div className="bg-white rounded-xl p-4 shadow-sm">
              <p className="font-semibold mb-2">Pesanan Terbaru</p>
              {orders.slice(0, 5).map((o) => (
                <div key={o.id} className="flex justify-between text-sm py-1 border-b last:border-0">
                  <span>{o.customer_name} {o.table_number ? `(${o.table_number})` : ""}</span>
                  <span className={`px-2 rounded-full text-xs ${STATUS_COLOR[o.status]}`}>
                    {o.status}
                  </span>
                </div>
              ))}
              {orders.length === 0 && <p className="text-sm text-gray-400">Belum ada pesanan.</p>}
            </div>
          </div>
        )}

        {/* ---------------- DAPUR ---------------- */}
        {tab === "dapur" && (
          <div className="space-y-3">
            <p className="text-sm text-gray-500 mb-1">
              Pesanan yang masih perlu disiapkan (pending / diproses)
            </p>
            {kitchenOrders.length === 0 && (
              <p className="text-gray-400 text-sm">Tidak ada pesanan yang perlu disiapkan. 🎉</p>
            )}
            {kitchenOrders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                items={orderItemsMap[order.id]}
                onToggleItems={() => loadOrderItems(order.id)}
                onUpdateStatus={updateStatus}
                big
              />
            ))}
          </div>
        )}

        {/* ---------------- MEJA & QR ---------------- */}
        {tab === "meja" && (
          <div className="space-y-4">
            <form onSubmit={addTable} className="bg-white rounded-xl p-3 shadow-sm flex gap-2">
              <input
                className="flex-1 border rounded-lg p-2"
                placeholder="Nama meja, contoh: Meja 1"
                value={newTableName}
                onChange={(e) => setNewTableName(e.target.value)}
              />
              <button type="submit" className="bg-black text-white px-4 rounded-lg font-medium">
                Tambah
              </button>
            </form>

            <div className="grid grid-cols-2 gap-3">
              {tables.map((t) => {
                const link = `${siteUrl}/?meja=${encodeURIComponent(t.name)}`;
                const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
                  link
                )}`;
                return (
                  <div key={t.id} className="bg-white rounded-xl p-3 shadow-sm text-center">
                    <p className="font-semibold mb-2">{t.name}</p>
                    {siteUrl ? (
                      <img src={qrUrl} alt={`QR ${t.name}`} className="mx-auto w-32 h-32" />
                    ) : (
                      <div className="w-32 h-32 bg-gray-100 mx-auto" />
                    )}
                    <p className="text-xs text-gray-400 mt-2 break-all">{link}</p>
                    <div className="flex justify-center gap-3 mt-2 text-sm">
                      <a
                        href={qrUrl}
                        download={`qr-${t.name}.png`}
                        className="text-blue-600"
                      >
                        Unduh QR
                      </a>
                      <button onClick={() => deleteTable(t.id)} className="text-red-600">
                        Hapus
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            {tables.length === 0 && (
              <p className="text-sm text-gray-400">
                Belum ada meja. Tambahkan meja di atas untuk membuat QR code-nya.
              </p>
            )}
          </div>
        )}

        {/* ---------------- RIWAYAT ---------------- */}
        {tab === "riwayat" && (
          <div className="space-y-3">
            {orders.length === 0 && <p className="text-gray-400 text-sm">Belum ada riwayat pesanan.</p>}
            {orders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                items={orderItemsMap[order.id]}
                onToggleItems={() => loadOrderItems(order.id)}
                onUpdateStatus={updateStatus}
              />
            ))}
          </div>
        )}

        {/* ---------------- PENGELUARAN ---------------- */}
        {tab === "pengeluaran" && (
          <div className="space-y-4">
            <form onSubmit={addExpense} className="bg-white rounded-xl p-3 shadow-sm space-y-2">
              <p className="font-semibold">Catat Pengeluaran</p>
              <input
                className="w-full border rounded-lg p-2"
                placeholder="Contoh: Belanja sayur & daging"
                value={expenseForm.description}
                onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                required
              />
              <input
                type="number"
                className="w-full border rounded-lg p-2"
                placeholder="Jumlah (Rp)"
                value={expenseForm.amount}
                onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                required
              />
              <input
                type="date"
                className="w-full border rounded-lg p-2"
                value={expenseForm.expense_date}
                onChange={(e) => setExpenseForm({ ...expenseForm, expense_date: e.target.value })}
              />
              <button type="submit" className="w-full bg-black text-white py-2 rounded-lg font-semibold">
                Simpan Pengeluaran
              </button>
            </form>

            <div className="bg-white rounded-xl p-3 shadow-sm">
              <p className="font-semibold mb-2">Total Bulan Ini: {formatRp(monthExpenseTotal)}</p>
              <div className="space-y-2">
                {expenses.map((e) => (
                  <div key={e.id} className="flex justify-between items-center text-sm border-b pb-2 last:border-0">
                    <div>
                      <p>{e.description}</p>
                      <p className="text-xs text-gray-400">{e.expense_date}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{formatRp(e.amount)}</span>
                      <button onClick={() => deleteExpense(e.id)} className="text-red-600 text-xs">
                        Hapus
                      </button>
                    </div>
                  </div>
                ))}
                {expenses.length === 0 && (
                  <p className="text-sm text-gray-400">Belum ada catatan pengeluaran.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- MENU ---------------- */}
        {tab === "menu" && (
          <div>
            <form onSubmit={saveMenuItem} className="bg-white rounded-xl p-3 shadow-sm space-y-2 mb-4">
              <p className="font-semibold">{editingId ? "Edit Menu" : "Tambah Menu Baru"}</p>
              <input
                className="w-full border rounded-lg p-2"
                placeholder="Nama menu"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
              <input
                className="w-full border rounded-lg p-2"
                placeholder="Deskripsi (opsional)"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
              <input
                type="number"
                className="w-full border rounded-lg p-2"
                placeholder="Harga (contoh: 15000)"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                required
              />
              <input
                className="w-full border rounded-lg p-2"
                placeholder="URL gambar (opsional)"
                value={form.image_url}
                onChange={(e) => setForm({ ...form, image_url: e.target.value })}
              />
              <div className="flex gap-2">
                <button type="submit" className="flex-1 bg-black text-white py-2 rounded-lg font-semibold">
                  {editingId ? "Simpan Perubahan" : "Tambah Menu"}
                </button>
                {editingId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingId(null);
                      setForm({ name: "", description: "", price: "", image_url: "" });
                    }}
                    className="px-4 bg-gray-200 rounded-lg"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>

            <div className="space-y-2">
              {menu.map((item) => (
                <div key={item.id} className="bg-white rounded-xl p-3 shadow-sm flex justify-between items-center">
                  <div>
                    <p className="font-semibold">{item.name}</p>
                    <p className="text-sm text-gray-500">
                      {formatRp(item.price)} &middot; {item.is_available ? "Tersedia" : "Nonaktif"}
                    </p>
                  </div>
                  <div className="flex gap-2 text-sm">
                    <button onClick={() => toggleAvailable(item)} className="text-blue-600">
                      {item.is_available ? "Nonaktifkan" : "Aktifkan"}
                    </button>
                    <button onClick={() => editItem(item)} className="text-gray-700">
                      Edit
                    </button>
                    <button onClick={() => deleteItem(item.id)} className="text-red-600">
                      Hapus
                    </button>
                  </div>
                </div>
              ))}
              {menu.length === 0 && <p className="text-sm text-gray-400">Belum ada menu.</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, highlight }) {
  return (
    <div className={`rounded-xl p-3 shadow-sm ${highlight ? "bg-black text-white" : "bg-white"}`}>
      <p className={`text-xs ${highlight ? "text-gray-300" : "text-gray-500"}`}>{label}</p>
      <p className="text-xl font-bold mt-1">{value}</p>
    </div>
  );
}

function OrderCard({ order, items, onToggleItems, onUpdateStatus, big }) {
  return (
    <div className={`bg-white rounded-xl p-3 shadow-sm ${big ? "border-l-4 border-black" : ""}`}>
      <div className="flex justify-between items-start">
        <div>
          <p className="font-semibold">{order.customer_name}</p>
          <p className="text-sm text-gray-500">
            Meja: {order.table_number || "-"} &middot; {new Date(order.created_at).toLocaleString("id-ID")}
          </p>
          {order.notes && <p className="text-sm text-gray-500">Catatan: {order.notes}</p>}
        </div>
        <p className="font-semibold">{formatRp(order.total)}</p>
      </div>

      <div className="flex items-center justify-between mt-2">
        <button onClick={onToggleItems} className="text-sm text-blue-600">
          {items ? "Sembunyikan item" : "Lihat item"}
        </button>
        <select
          value={order.status}
          onChange={(e) => onUpdateStatus(order.id, e.target.value)}
          className={`border rounded-lg p-1 text-sm ${STATUS_COLOR[order.status]}`}
        >
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {items && (
        <ul className="mt-2 text-sm text-gray-600 border-t pt-2 space-y-1">
          {items.map((it) => (
            <li key={it.id}>
              {it.quantity}x {it.menu_name} — {formatRp(it.price * it.quantity)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
