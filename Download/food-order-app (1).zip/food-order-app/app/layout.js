import "./globals.css";

export const metadata = {
  title: "Menu Makanan",
  description: "Pesan menu makanan online",
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
