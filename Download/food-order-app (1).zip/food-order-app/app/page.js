"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { supabase } from "../lib/supabaseClient";

export default function HomePage() {
  return (
    <Suspense fallback={<p className="p-4">Memuat...</p>}>
      <HomePageInner />
    </Suspense>
  );
}

function HomePageInner() {
  const searchParams = useSearchParams();
  const mejaFromQr = searchParams.get("meja") || "";

  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState({});
  const [customerName, setCustomerName] = useState("");
  const [tableNumber, setTableNumber] = useState(mejaFromQr);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successOrderId, setSuccessOrderId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    loadMenu();
  }, []);

  async function loadMenu() {
    setLoading(true);
    const { data, error } = await supabase
      .from("menu_items")
      .select("*")
      .eq("is_available", true)
      .order("created_at", { ascending: true });
    if (!error) setMenu(data || []);
    setLoading(false);
  }

  function addToCart(item) {
    setCart((prev) => ({
      ...prev,
      [item.id]: { ...item, qty: (prev[item.id]?.qty || 0) + 1 },
    }));
  }

  function removeFromCart(item) {
    setCart((prev) => {
      const current = prev[item.id];
      if (!current) return prev;
      const nextQty = current.qty - 1;
      const copy = { ...prev };
      if (nextQty <= 0) {
        delete copy[item.id];
      } else {
        copy[item.id] = { ...current, qty: nextQty };
      }
      return copy;
    });
  }

  const cartItems = Object.values(cart);
  const total = cartItems.reduce((sum, i) => sum + i.price * i.qty, 0);

  async function submitOrder() {
    setError("");
    if (!customerName.trim()) {
      setError("Nama pemesan wajib diisi.");
      return;
    }
    if (cartItems.length === 0) {
      setError("Keranjang masih kosong.");
      return;
    }
    setSubmitting(true);

    const { data: order, error: orderErr } = await supabase
      .from("orders")
      .insert({
        customer_name: customerName,
        table_number: tableNumber,
        notes: notes,
        total: total,
        status: "pending",
      })
      .select()
      .single();

    if (orderErr) {
      setError("Gagal membuat pesanan: " + orderErr.message);
      setSubmitting(false);
      return;
    }

    const itemsPayload = cartItems.map((i) => ({
      order_id: order.id,
      menu_item_id: i.id,
      menu_name: i.name,
      price: i.price,
      quantity: i.qty,
    }));

    const { error: itemsErr } = await supabase
      .from("order_items")
      .insert(itemsPayload);

    if (itemsErr) {
      setError("Gagal menyimpan detail pesanan: " + itemsErr.message);
      setSubmitting(false);
      return;
    }

    setSuccessOrderId(order.id);
    setCart({});
    setCustomerName("");
    setTableNumber("");
    setNotes("");
    setSubmitting(false);
  }

  if (successOrderId) {
    return (
      <div className="max-w-md mx-auto p-6 text-center mt-20">
        <h1 className="text-2xl font-bold mb-2">Pesanan Diterima!</h1>
        <p className="text-gray-600 mb-4">
          Kode pesanan Anda: <span className="font-mono">{successOrderId.slice(0, 8)}</span>
        </p>
        <p className="text-gray-600 mb-6">
          Silakan bayar di kasir / tempat. Terima kasih!
        </p>
        <button
          onClick={() => setSuccessOrderId(null)}
          className="bg-black text-white px-4 py-2 rounded-lg"
        >
          Pesan Lagi
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto p-4 pb-40">
      <h1 className="text-2xl font-bold mb-1">Menu Kami</h1>
      {mejaFromQr && (
        <p className="text-sm text-gray-500 mb-4">
          Anda memesan untuk <span className="font-semibold">{mejaFromQr}</span>
        </p>
      )}
      {!mejaFromQr && <div className="mb-4" />}

      {loading && <p>Memuat menu...</p>}
      {!loading && menu.length === 0 && (
        <p className="text-gray-500">Belum ada menu tersedia.</p>
      )}

      <div className="space-y-3">
        {menu.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-xl p-3 shadow-sm flex items-center gap-3"
          >
            {item.image_url ? (
              <img
                src={item.image_url}
                alt={item.name}
                className="w-16 h-16 object-cover rounded-lg"
              />
            ) : (
              <div className="w-16 h-16 bg-gray-200 rounded-lg flex-shrink-0" />
            )}
            <div className="flex-1">
              <p className="font-semibold">{item.name}</p>
              {item.description && (
                <p className="text-sm text-gray-500">{item.description}</p>
              )}
              <p className="text-sm font-medium mt-1">
                Rp {item.price.toLocaleString("id-ID")}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {cart[item.id]?.qty > 0 && (
                <>
                  <button
                    onClick={() => removeFromCart(item)}
                    className="w-8 h-8 rounded-full bg-gray-200 font-bold"
                  >
                    -
                  </button>
                  <span className="w-4 text-center">{cart[item.id].qty}</span>
                </>
              )}
              <button
                onClick={() => addToCart(item)}
                className="w-8 h-8 rounded-full bg-black text-white font-bold"
              >
                +
              </button>
            </div>
          </div>
        ))}
      </div>

      {cartItems.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4 max-w-md mx-auto">
          <div className="flex justify-between mb-2 font-semibold">
            <span>Total</span>
            <span>Rp {total.toLocaleString("id-ID")}</span>
          </div>
          <input
            className="w-full border rounded-lg p-2 mb-2"
            placeholder="Nama Anda"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
          />
          <input
            className="w-full border rounded-lg p-2 mb-2"
            placeholder="No. Meja (opsional)"
            value={tableNumber}
            onChange={(e) => setTableNumber(e.target.value)}
          />
          <input
            className="w-full border rounded-lg p-2 mb-2"
            placeholder="Catatan (opsional)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
          {error && <p className="text-red-600 text-sm mb-2">{error}</p>}
          <button
            onClick={submitOrder}
            disabled={submitting}
            className="w-full bg-black text-white py-3 rounded-lg font-semibold disabled:opacity-50"
          >
            {submitting ? "Mengirim..." : "Pesan Sekarang (Bayar di Tempat)"}
          </button>
        </div>
      )}
    </div>
  );
}
