-- JALANKAN INI kalau database Anda SUDAH ada isinya sebelumnya (sudah pernah run schema.sql versi lama).
-- Kalau baru mulai dari nol, langsung pakai schema.sql saja, tidak perlu file ini.

create table if not exists tables (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamp with time zone default now()
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  description text not null,
  amount integer not null,
  expense_date date not null default current_date,
  created_at timestamp with time zone default now()
);

alter table tables enable row level security;
alter table expenses enable row level security;

drop policy if exists "Meja bisa dibaca semua orang" on tables;
create policy "Meja bisa dibaca semua orang"
  on tables for select using (true);

drop policy if exists "Admin bisa kelola meja" on tables;
create policy "Admin bisa kelola meja"
  on tables for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');

drop policy if exists "Admin bisa kelola pengeluaran" on expenses;
create policy "Admin bisa kelola pengeluaran"
  on expenses for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');
