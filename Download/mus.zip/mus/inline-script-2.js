
        window.lucide = window.lucide || { createIcons: function() {} };
    