import { NextResponse } from "next/server";

export function middleware(request) {
  // Route guard dasar. RLS Supabase tetap menjadi pengaman utama data.
  if (request.nextUrl.pathname.startsWith("/admin") &&
      request.nextUrl.pathname !== "/admin/login") {
    if (!request.cookies.get("admin-session")) {
      return NextResponse.redirect(new URL("/admin/login", request.url));
    }
  }
  return NextResponse.next();
}
export const config = { matcher:["/admin/:path*"] };