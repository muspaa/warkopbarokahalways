# Kedai Kita — QR Table Ordering

Alur:
1. Customer scan QR meja.
2. URL membawa `?meja=01`.
3. Customer tidak memilih nomor meja.
4. Customer memilih menu dan checkout.
5. Order masuk ke Supabase.
6. Dashboard kasir menerima realtime notification.
7. Kasir menerima order -> `diproses`.
8. Dapur melihat order realtime -> `selesai`.

Setup:
- `npm install`
- isi `.env.local`
- jalankan `supabase/schema.sql`
- `npm run dev`
- deploy ke Vercel
- masukkan env yang sama di Vercel.

QR:
`https://domain-kamu.vercel.app/?meja=01`
`https://domain-kamu.vercel.app/?meja=02`
dan seterusnya.

Catatan:
- Jangan pernah memasukkan `service_role` key ke frontend.
- Untuk produksi, gunakan Supabase SSR auth dan RLS dengan role admin yang lebih ketat.
