-- Jalankan di Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'Makanan',
  description text,
  price integer not null check(price >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  table_number text not null,
  status text not null default 'baru'
    check(status in ('baru','diproses','selesai','dibatalkan')),
  items jsonb not null default '[]'::jsonb,
  total integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.menu_items enable row level security;
alter table public.orders enable row level security;

drop policy if exists "public menu read" on public.menu_items;
create policy "public menu read"
on public.menu_items for select to anon,authenticated
using(is_available=true);

drop policy if exists "authenticated menu manage" on public.menu_items;
create policy "authenticated menu manage"
on public.menu_items for all to authenticated
using(true) with check(true);

drop policy if exists "customer create order" on public.orders;
create policy "customer create order"
on public.orders for insert to anon,authenticated
with check(table_number is not null and length(trim(table_number))>0);

drop policy if exists "authenticated order read" on public.orders;
create policy "authenticated order read"
on public.orders for select to authenticated
using(true);

drop policy if exists "authenticated order update" on public.orders;
create policy "authenticated order update"
on public.orders for update to authenticated
using(true) with check(true);

alter publication supabase_realtime add table public.orders;

-- Opsional: isi contoh menu
insert into public.menu_items(name,category,price,description)
values
('Nasi Goreng Spesial','Makanan',18000,'Nasi goreng gurih dengan telur.'),
('Mie Goreng Jawa','Makanan',17000,'Mie goreng dengan sayur dan telur.'),
('Es Kopi Susu','Minuman',12000,'Kopi susu creamy.'),
('Teh Manis','Minuman',6000,'Teh manis segar.')
on conflict do nothing;
