"use client";

import {useEffect,useMemo,useState} from "react";
import {Search,ShoppingBag,Plus,Minus,X,MapPin,CheckCircle} from "lucide-react";
import {createClient} from "../lib/supabaseClient";

const fallback=[
 {id:"demo1",name:"Nasi Goreng Spesial",category:"Makanan",price:18000,description:"Nasi goreng gurih dengan telur dan topping pilihan.",image_url:""},
 {id:"demo2",name:"Mie Goreng Jawa",category:"Makanan",price:17000,description:"Mie goreng khas dengan sayur dan telur.",image_url:""},
 {id:"demo3",name:"Es Kopi Susu",category:"Minuman",price:12000,description:"Kopi susu creamy dengan rasa kopi seimbang.",image_url:""},
 {id:"demo4",name:"Teh Manis",category:"Minuman",price:6000,description:"Teh manis segar untuk menemani makanan.",image_url:""}
];

export default function Home(){
 const supabase=createClient();
 const [table,setTable]=useState(null);
 const [menu,setMenu]=useState([]);
 const [cat,setCat]=useState("Semua");
 const [search,setSearch]=useState("");
 const [cart,setCart]=useState([]);
 const [open,setOpen]=useState(false);
 const [sending,setSending]=useState(false);
 const [success,setSuccess]=useState(false);

 useEffect(()=>{
   const params=new URLSearchParams(window.location.search);
   const raw=params.get("meja");
   if(raw) setTable(raw);
   load();
 },[]);

 async function load(){
   const {data}=await supabase.from("menu_items").select("*").eq("is_available",true).order("created_at",{ascending:false});
   setMenu(data?.length?data:fallback);
 }
 const cats=["Semua",...new Set(menu.map(x=>x.category))];
 const shown=useMemo(()=>menu.filter(x=>
   (cat==="Semua"||x.category===cat)&&x.name.toLowerCase().includes(search.toLowerCase())
 ),[menu,cat,search]);
 const count=cart.reduce((a,x)=>a+x.qty,0);
 const total=cart.reduce((a,x)=>a+x.price*x.qty,0);

 function add(item){setCart(c=>{const f=c.find(x=>x.id===item.id);return f?c.map(x=>x.id===item.id?{...x,qty:x.qty+1}:x):[...c,{...item,qty:1}]})}
 function change(id,d){setCart(c=>c.map(x=>x.id===id?{...x,qty:x.qty+d}:x).filter(x=>x.qty>0))}

 async function order(){
   if(!cart.length||!table||sending)return;
   setSending(true);
   const payload={
     table_number:String(table),
     status:"baru",
     items:cart.map(x=>({id:x.id,name:x.name,price:x.price,qty:x.qty})),
     total
   };
   const {error}=await supabase.from("orders").insert(payload);
   setSending(false);
   if(error){alert("Pesanan gagal dikirim: "+error.message);return}
   setCart([]);setOpen(false);setSuccess(true);
 }

 return <main>
  <header className="sticky top-0 z-30 border-b bg-white/85 backdrop-blur">
   <div className="app flex items-center justify-between py-3">
    <div><b className="text-xl">Kedai Kita</b><p className="text-xs text-neutral-500">Menu makanan & minuman</p></div>
    <button className="btn primary relative" onClick={()=>setOpen(true)}><ShoppingBag size={18}/>{count>0&&<span className="absolute -right-2 -top-2 grid h-5 w-5 place-items-center rounded-full bg-red-500 text-xs text-white">{count}</span>}</button>
   </div>
  </header>

  <section className="app py-6">
   <div className="rounded-[28px] bg-[#3e2b20] p-6 text-white shadow-lg">
    <div className="flex items-center gap-2 text-sm text-white/75"><MapPin size={16}/>{table?<><span>Meja</span><b className="text-white">{table}</b></>:<span>Silakan scan QR meja terlebih dahulu</span>}</div>
    <h1 className="mt-3 text-3xl font-black">Mau makan apa hari ini?</h1>
    <p className="mt-2 text-sm text-white/70">Pilih menu dan kirim pesanan langsung ke kasir.</p>
    <div className="mt-5 flex items-center gap-2 rounded-2xl bg-white p-2 text-black"><Search size={18} className="ml-2 text-neutral-400"/><input className="w-full bg-transparent p-2 outline-0" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari menu..."/></div>
   </div>
  </section>

  {!table&&<section className="app pb-4"><div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900"><b>QR meja belum terdeteksi.</b><br/>Silakan scan QR yang tersedia di meja untuk mulai memesan.</div></section>}

  <section className="app pb-24">
   <div className="mb-5 flex gap-2 overflow-x-auto pb-1">{cats.map(c=><button key={c} onClick={()=>setCat(c)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold ${cat===c?"bg-[#6f4e37] text-white":"border bg-white text-neutral-600"}`}>{c}</button>)}</div>
   <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
    {shown.map((x,i)=><article key={x.id} className="card fade overflow-hidden" style={{animationDelay:`${i*30}ms`}}>
     <div className="aspect-[4/3] bg-gradient-to-br from-[#eadfd5] to-[#cbb7a6]">{x.image_url&&<img src={x.image_url} className="h-full w-full object-cover" alt={x.name}/>}</div>
     <div className="p-3"><span className="text-[10px] font-black uppercase tracking-wider text-[#8c6a52]">{x.category}</span><h2 className="mt-1 line-clamp-1 font-extrabold">{x.name}</h2><p className="mt-1 min-h-10 line-clamp-2 text-xs text-neutral-500">{x.description}</p><div className="mt-3 flex items-center justify-between"><b className="text-sm">{rupiah(x.price)}</b><button disabled={!table} className="btn primary !p-2 disabled:opacity-40" onClick={()=>add(x)}><Plus size={18}/></button></div></div>
    </article>)}
   </div>
  </section>

  {success&&<div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-5"><div className="card w-full max-w-sm p-6 text-center"><CheckCircle className="mx-auto text-green-600" size={48}/><h2 className="mt-3 text-2xl font-black">Pesanan Terkirim!</h2><p className="mt-2 text-sm text-neutral-500">Pesanan meja {table} sudah masuk ke kasir.</p><button className="btn primary mt-5 w-full" onClick={()=>setSuccess(false)}>Kembali ke Menu</button></div></div>}

  {open&&<div className="fixed inset-0 z-50 bg-black/40" onClick={()=>setOpen(false)}><aside onClick={e=>e.stopPropagation()} className="absolute right-0 top-0 h-full w-full max-w-md overflow-y-auto bg-[#faf9f7] p-5">
   <div className="flex items-center justify-between"><h2 className="text-xl font-black">Keranjang</h2><button onClick={()=>setOpen(false)}><X/></button></div>
   <div className="mt-5 space-y-3">{cart.length?cart.map(x=><div className="card p-3" key={x.id}><div className="flex justify-between gap-3"><div><b>{x.name}</b><p className="text-sm text-neutral-500">{rupiah(x.price)}</p></div><b>{rupiah(x.price*x.qty)}</b></div><div className="mt-3 flex items-center gap-3"><button className="btn soft !p-2" onClick={()=>change(x.id,-1)}><Minus size={15}/></button><b>{x.qty}</b><button className="btn soft !p-2" onClick={()=>change(x.id,1)}><Plus size={15}/></button></div></div>):<p className="py-16 text-center text-neutral-500">Keranjang kosong.</p>}</div>
   <div className="mt-5 border-t pt-5"><div className="flex justify-between"><span>Meja</span><b>{table||"-"}</b></div><div className="mt-2 flex justify-between"><span>Total</span><b className="text-xl">{rupiah(total)}</b></div><button disabled={!cart.length||!table||sending} onClick={order} className="btn primary mt-5 w-full disabled:opacity-40">{sending?"Mengirim...":"Pesan Sekarang"}</button></div>
  </aside></div>}
 </main>
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}