"use client";
import {useEffect,useState} from "react";
import {createClient} from "../../../lib/supabaseClient";
export default function Menu(){
 const supabase=createClient();const empty={name:"",category:"Makanan",price:"",description:"",image_url:"",is_available:true};const[form,setForm]=useState(empty),[rows,setRows]=useState([]);
 async function load(){const{data}=await supabase.from("menu_items").select("*").order("created_at",{ascending:false});setRows(data||[])}
 useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();await supabase.from("menu_items").insert({...form,price:Number(form.price)});setForm(empty);load()}
 async function del(id){await supabase.from("menu_items").delete().eq("id",id);load()}
 return <div className="app py-8"><h1 className="text-3xl font-black">Kelola Menu</h1><form onSubmit={add} className="card mt-6 grid gap-3 p-5 md:grid-cols-2"><input className="input" placeholder="Nama menu" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/><select className="input" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Makanan</option><option>Minuman</option><option>Snack</option></select><input className="input" type="number" placeholder="Harga" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} required/><input className="input" placeholder="URL gambar (opsional)" value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})}/><textarea className="input md:col-span-2" placeholder="Deskripsi" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><button className="btn primary md:col-span-2">Tambah Menu</button></form><div className="mt-6 grid gap-3">{rows.map(x=><div className="card flex items-center justify-between p-4" key={x.id}><div><b>{x.name}</b><p className="text-sm text-neutral-500">{x.category} · {rupiah(x.price)}</p></div><button className="btn soft" onClick={()=>del(x.id)}>Hapus</button></div>)}</div></div>
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}