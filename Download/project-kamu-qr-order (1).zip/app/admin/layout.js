import Link from "next/link";
export default function AdminLayout({children}){
 return <div className="min-h-screen md:flex">
  <aside className="hidden w-64 shrink-0 border-r bg-white p-5 md:block"><b className="text-xl">Kedai Admin</b><nav className="mt-8 grid gap-3 text-sm font-semibold"><Link href="/admin">Dashboard</Link><Link href="/admin/orders">Pesanan 🔔</Link><Link href="/admin/dapur">Dapur</Link><Link href="/admin/menu">Menu</Link><Link href="/admin/meja">Meja & QR</Link><Link href="/admin/riwayat">Riwayat</Link></nav></aside>
  <main className="min-w-0 flex-1">{children}</main>
 </div>
}