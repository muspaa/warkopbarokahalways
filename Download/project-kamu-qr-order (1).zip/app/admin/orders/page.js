"use client";
import {useEffect,useState} from "react";
import {Bell,Check} from "lucide-react";
import {createClient} from "../../../lib/supabaseClient";

export default function Orders(){
 const supabase=createClient();const[rows,setRows]=useState([]);const[newOrder,setNewOrder]=useState(null);
 async function load(){const{data}=await supabase.from("orders").select("*").order("created_at",{ascending:false});setRows(data||[])}
 useEffect(()=>{
  load();
  const ch=supabase.channel("orders-realtime").on("postgres_changes",{event:"INSERT",schema:"public",table:"orders"},payload=>{
   setNewOrder(payload.new);load();try{new Audio("/notification.mp3").play()}catch{}
  }).on("postgres_changes",{event:"UPDATE",schema:"public",table:"orders"},load).subscribe();
  return()=>supabase.removeChannel(ch)
 },[]);
 async function update(id,status){await supabase.from("orders").update({status}).eq("id",id);load()}
 return <div className="app py-8">
  {newOrder&&<div className="fixed right-4 top-4 z-50 w-[calc(100%-32px)] max-w-sm rounded-2xl bg-[#3e2b20] p-4 text-white shadow-2xl"><div className="flex gap-3"><Bell/><div><b>Pesanan Baru!</b><p className="text-sm text-white/75">Meja {newOrder.table_number} · {rupiah(newOrder.total)}</p></div></div><button className="btn mt-3 w-full bg-white text-[#3e2b20]" onClick={()=>setNewOrder(null)}>Lihat Pesanan</button></div>}
  <div className="flex items-center justify-between"><div><p className="text-sm text-neutral-500">Kasir</p><h1 className="text-3xl font-black">Pesanan Masuk</h1></div><span className="rounded-full bg-green-100 px-3 py-2 text-xs font-bold text-green-700">● REALTIME</span></div>
  <div className="mt-6 grid gap-3">{rows.map(o=><div key={o.id} className="card p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><b className="text-lg">Meja {o.table_number}</b><p className="text-xs text-neutral-500">{new Date(o.created_at).toLocaleString("id-ID")}</p></div><span className="rounded-full bg-neutral-100 px-3 py-1 text-xs font-bold">{o.status}</span></div><div className="mt-4 space-y-2">{(o.items||[]).map((x,i)=><div key={i} className="flex justify-between text-sm"><span>{x.qty} × {x.name}</span><b>{rupiah(x.price*x.qty)}</b></div>)}</div><div className="mt-4 flex items-center justify-between border-t pt-3"><b>{rupiah(o.total)}</b><div className="flex gap-2">{o.status==="baru"&&<button className="btn primary" onClick={()=>update(o.id,"diproses")}><Check size={16}/>Terima</button>}{o.status==="diproses"&&<button className="btn primary" onClick={()=>update(o.id,"selesai")}>Selesai</button>}</div></div></div>)}</div>
 </div>
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}