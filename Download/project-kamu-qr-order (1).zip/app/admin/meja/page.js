"use client";
import {useState} from "react";
import {Copy,ExternalLink} from "lucide-react";
export default function Meja(){
 const[base,setBase]=useState("");const[count,setCount]=useState(12);
 const urls=Array.from({length:Number(count)||0},(_,i)=>({n:i+1,url:`${base||"https://website-kamu.vercel.app"}/?meja=${i+1}`}));
 return <div className="app py-8"><h1 className="text-3xl font-black">Meja & QR</h1><p className="mt-2 text-neutral-500">Setiap meja memiliki URL QR sendiri. Pelanggan tidak memilih meja.</p><div className="card mt-6 grid gap-3 p-5 md:grid-cols-2"><input className="input" value={base} onChange={e=>setBase(e.target.value)} placeholder="URL website Vercel, contoh https://kedai.vercel.app"/><input className="input" type="number" min="1" max="100" value={count} onChange={e=>setCount(e.target.value)} placeholder="Jumlah meja"/></div><div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{urls.map(x=><div className="card p-4" key={x.n}><b>Meja {x.n}</b><p className="mt-2 break-all text-xs text-neutral-500">{x.url}</p><div className="mt-3 flex gap-2"><button className="btn soft" onClick={()=>navigator.clipboard.writeText(x.url)}><Copy size={15}/>Salin</button><a className="btn primary" href={x.url} target="_blank"><ExternalLink size={15}/>Buka</a></div></div>)}</div></div>
}