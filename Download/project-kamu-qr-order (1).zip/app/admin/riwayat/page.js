"use client";
import {useEffect,useState} from "react";
import {createClient} from "../../../lib/supabaseClient";
export default function History(){
 const supabase=createClient();const[rows,setRows]=useState([]);
 useEffect(()=>{supabase.from("orders").select("*").eq("status","selesai").order("created_at",{ascending:false}).then(({data})=>setRows(data||[]))},[]);
 return <div className="app py-8"><h1 className="text-3xl font-black">Riwayat Pesanan</h1><div className="mt-6 grid gap-3">{rows.map(o=><div className="card flex justify-between p-4" key={o.id}><div><b>Meja {o.table_number}</b><p className="text-sm text-neutral-500">{new Date(o.created_at).toLocaleString("id-ID")}</p></div><b>{rupiah(o.total)}</b></div>)}</div></div>
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}