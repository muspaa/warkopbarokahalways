"use client";
import {useState} from "react";
import {useRouter} from "next/navigation";
import {createClient} from "../../../lib/supabaseClient";
export default function Login(){
 const supabase=createClient(),router=useRouter();const[email,setEmail]=useState(""),[password,setPassword]=useState(""),[error,setError]=useState("");
 async function submit(e){e.preventDefault();const{data,error}=await supabase.auth.signInWithPassword({email,password});if(error)return setError(error.message);document.cookie=`admin-session=${data.session.access_token}; Path=/; Max-Age=86400; SameSite=Lax`;router.push("/admin/orders")}
 return <main className="grid min-h-screen place-items-center p-5"><form onSubmit={submit} className="card w-full max-w-sm p-6 shadow-lg"><p className="text-sm text-neutral-500">Kedai Kita</p><h1 className="mt-1 text-2xl font-black">Login Kasir</h1><div className="mt-5 grid gap-3"><input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="input" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/></div>{error&&<p className="mt-3 text-sm text-red-600">{error}</p>}<button className="btn primary mt-5 w-full">Masuk Dashboard</button></form></main>
}