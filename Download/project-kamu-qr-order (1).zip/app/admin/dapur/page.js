"use client";
import {useEffect,useState} from "react";
import {createClient} from "../../../lib/supabaseClient";
export default function Dapur(){
 const supabase=createClient();const[rows,setRows]=useState([]);
 async function load(){const{data}=await supabase.from("orders").select("*").in("status",["baru","diproses"]).order("created_at");setRows(data||[])}
 useEffect(()=>{load();const ch=supabase.channel("kitchen").on("postgres_changes",{event:"*",schema:"public",table:"orders"},load).subscribe();return()=>supabase.removeChannel(ch)},[]);
 async function done(id){await supabase.from("orders").update({status:"selesai"}).eq("id",id);load()}
 return <div className="app py-8"><h1 className="text-3xl font-black">Dapur</h1><div className="mt-6 grid gap-3">{rows.map(o=><div className="card p-4" key={o.id}><div className="flex justify-between"><b>Meja {o.table_number}</b><span>{o.status}</span></div><div className="mt-4 grid gap-2">{(o.items||[]).map((x,i)=><div className="flex justify-between" key={i}><span>{x.qty} × {x.name}</span><b>{rupiah(x.price*x.qty)}</b></div>)}</div><button className="btn primary mt-4 w-full" onClick={()=>done(o.id)}>Tandai Selesai</button></div>)}</div></div>
}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n)}