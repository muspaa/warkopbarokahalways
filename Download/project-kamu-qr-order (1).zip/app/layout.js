import "./globals.css";
export const metadata={
  title:"Kedai Kita",
  description:"Sistem menu dan pemesanan QR meja"
};
export default function RootLayout({children}) {
  return <html lang="id"><body>{children}</body></html>;
}