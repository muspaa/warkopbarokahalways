// Server-side API configuration.
// Set YOUTUBE_API_KEY in your deployment environment.
// Never expose this value in frontend JavaScript.
function getYoutubeApiKey() {
  const key = process.env.YOUTUBE_API_KEY;
  if (!key) throw new Error('YOUTUBE_API_KEY belum dikonfigurasi');
  return key;
}
module.exports = { getYoutubeApiKey };
