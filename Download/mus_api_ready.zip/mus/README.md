# NanzMusify

## Deploy
1. Install dependencies: `npm install`
2. Configure environment variable `YOUTUBE_API_KEY` using the value of your YouTube API key.
3. Deploy the project with Node/Vercel-compatible serverless functions.
4. The frontend calls `/api/search`, `/api/artist`, `/api/album`, `/api/suggest`, `/api/lyrics`, and `/api/ytplay`.

The API key is intentionally server-side only and is not placed in frontend JavaScript.
