# Warkop Barockah Always
Website landing page modern untuk warung kopi, dibuat responsive untuk HP dan desktop.

## Fitur
- Hero branding memakai gambar/logo yang diberikan.
- Menu makanan & minuman.
- Filter kategori.
- Keranjang pesanan interaktif.
- Responsive mobile navigation.
- Galeri dan section kontak.
- Tidak membutuhkan backend untuk demo.

## Jalankan
Bisa langsung dibuka dengan browser atau jalankan server lokal:

```bash
python -m http.server 3001
```

Lalu buka `http://localhost:3001`.
