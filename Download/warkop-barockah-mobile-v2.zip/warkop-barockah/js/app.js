const WHATSAPP_NUMBER = '6287712922471';
const menu = [
  {name:'Kopi Hitam',cat:'minuman',price:8000,img:'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=85',desc:'Kopi hitam klasik, pekat dan wangi.'},
  {name:'Kopi Susu',cat:'minuman',price:10000,img:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85',desc:'Creamy, manis pas, cocok kapan saja.'},
  {name:'Es Teh Manis',cat:'minuman',price:5000,img:'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=900&q=85',desc:'Segar untuk teman makan dan ngobrol.'},
  {name:'Matcha Latte',cat:'minuman',price:15000,img:'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=900&q=85',desc:'Lembut, creamy, dan harum matcha.'},
  {name:'Es Coklat',cat:'minuman',price:12000,img:'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=900&q=85',desc:'Coklat dingin dengan rasa manis yang pas.'},
  {name:'Es Jeruk',cat:'minuman',price:10000,img:'https://images.unsplash.com/photo-1621263764928-df1444c5e859?auto=format&fit=crop&w=900&q=85',desc:'Segar dan ringan untuk menemani makan.'},
  {name:'Indomie Goreng',cat:'makanan',price:12000,img:'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=900&q=85',desc:'Favorit warkop dengan topping lengkap.'},
  {name:'Nasi Goreng',cat:'makanan',price:16000,img:'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=900&q=85',desc:'Gurih, smoky, dan bikin kenyang.'},
  {name:'Roti Bakar',cat:'makanan',price:10000,img:'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=85',desc:'Roti renyah dengan isian favorit.'},
  {name:'Pisang Coklat',cat:'makanan',price:8000,img:'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=900&q=85',desc:'Manis legit untuk teman ngopi.'},
  {name:'Kentang Goreng',cat:'makanan',price:10000,img:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85',desc:'Renyah, gurih, cocok untuk sharing.'},
  {name:'Bakso Kuah',cat:'makanan',price:15000,img:'https://images.unsplash.com/photo-1555126634-323283e090fa?auto=format&fit=crop&w=900&q=85',desc:'Hangat dan gurih untuk malam hari.'}
];
let cart=[];
const rupiah=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const grid=document.querySelector('#menuGrid');
const cartEl=document.querySelector('#cart');
const overlay=document.querySelector('#overlay');

function renderMenu(filter='all'){
  grid.innerHTML=menu.map((m,i)=>filter!=='all'&&m.cat!==filter?'':`<article class="menu-card reveal" data-index="${i}">
    <div class="menu-photo"><img src="${m.img}" alt="${m.name}" loading="lazy"><span class="category-pill">${m.cat==='minuman'?'MINUMAN':'MAKANAN'}</span></div>
    <div class="menu-info"><h3>${m.name}</h3><p>${m.desc}</p><div class="menu-row"><span class="price">${rupiah(m.price)}</span><button class="add" aria-label="Tambah ${m.name}" onclick="addToCart(${i})"><span>+</span></button></div></div>
  </article>`).join('');
  observeReveals();
}
function addToCart(i){const found=cart.find(x=>x.i===i);if(found)found.qty++;else cart.push({i,qty:1});renderCart();openCart();toast(`${menu[i].name} ditambahkan`)}
function renderCart(){const el=document.querySelector('#cartItems');document.querySelector('#cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0);if(!cart.length){el.innerHTML='<div class="empty"><div>🛒</div><p>Keranjang masih kosong.</p><small>Pilih menu favoritmu untuk mulai pesan.</small></div>';document.querySelector('#cartTotal').textContent=rupiah(0);return}el.innerHTML=cart.map(x=>{const m=menu[x.i];return `<div class="cart-item"><img src="${m.img}" alt="${m.name}"><div class="cart-main"><strong>${m.name}</strong><small>${rupiah(m.price)} / item</small></div><div class="qty"><button onclick="changeQty(${x.i},-1)">−</button><b>${x.qty}</b><button onclick="changeQty(${x.i},1)">+</button></div></div>`}).join('');document.querySelector('#cartTotal').textContent=rupiah(cart.reduce((s,x)=>s+menu[x.i].price*x.qty,0))}
function changeQty(i,d){const x=cart.find(x=>x.i===i);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(x=>x.i!==i);renderCart()}
function openCart(){cartEl.classList.add('open');overlay.classList.add('show');document.body.classList.add('locked')}
function closeCart(){cartEl.classList.remove('open');overlay.classList.remove('show');document.body.classList.remove('locked')}
function checkout(){if(!cart.length){toast('Tambahkan menu terlebih dahulu');openCart();return}const lines=cart.map(x=>`• ${menu[x.i].name} x${x.qty} — ${rupiah(menu[x.i].price*x.qty)}`);const total=cart.reduce((s,x)=>s+menu[x.i].price*x.qty,0);const text=`Halo Warkop Barockah Always 👋\n\nSaya ingin memesan:\n${lines.join('\n')}\n\nTotal: ${rupiah(total)}\n\nMohon konfirmasi pesanan saya. Terima kasih.`;window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`,'_blank','noopener,noreferrer')}
function toast(msg){const t=document.querySelector('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),1800)}

document.querySelector('#cartBtn').onclick=openCart;
document.querySelector('#closeCart').onclick=closeCart;
overlay.onclick=closeCart;
document.querySelector('#checkout').onclick=checkout;
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderMenu(b.dataset.filter)});
document.querySelector('#menuToggle').onclick=()=>document.querySelector('#nav').classList.toggle('open');
document.querySelectorAll('.nav a').forEach(a=>a.onclick=()=>document.querySelector('#nav').classList.remove('open'));
document.querySelectorAll('[data-order]').forEach(b=>b.onclick=()=>{document.querySelector('#menu').scrollIntoView({behavior:'smooth'});setTimeout(()=>document.querySelector('.menu-card .add')?.focus(),500)});

const revealObserver=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');revealObserver.unobserve(e.target)}}),{threshold:.12});
function observeReveals(){document.querySelectorAll('.reveal:not(.visible)').forEach(el=>revealObserver.observe(el))}
document.querySelectorAll('section,.benefits,.contact-card,footer').forEach(el=>el.classList.add('scroll-reveal'));document.querySelectorAll('.scroll-reveal').forEach(el=>revealObserver.observe(el));
window.addEventListener('scroll',()=>document.querySelector('.site-header').classList.toggle('scrolled',scrollY>18),{passive:true});
renderMenu();renderCart();
