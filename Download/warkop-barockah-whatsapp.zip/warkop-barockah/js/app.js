const WHATSAPP_NUMBER = '6287712922471';

const menu = [
  {name:'Kopi Hitam',cat:'minuman',price:8000,img:'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=700&q=80',desc:'Kopi hitam klasik, pekat dan wangi.'},
  {name:'Kopi Susu',cat:'minuman',price:10000,img:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=700&q=80',desc:'Creamy, manis pas, cocok kapan saja.'},
  {name:'Es Teh Manis',cat:'minuman',price:5000,img:'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=700&q=80',desc:'Segar untuk teman makan dan ngobrol.'},
  {name:'Matcha Latte',cat:'minuman',price:15000,img:'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=700&q=80',desc:'Lembut, creamy, dan harum matcha.'},
  {name:'Es Coklat',cat:'minuman',price:12000,img:'https://images.unsplash.com/photo-1542990253-0d0f5be5f0ed?auto=format&fit=crop&w=700&q=80',desc:'Coklat dingin yang creamy dan nikmat.'},
  {name:'Es Jeruk',cat:'minuman',price:10000,img:'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=700&q=80',desc:'Segar, asam manis, cocok siang hari.'},
  {name:'Indomie Goreng',cat:'makanan',price:12000,img:'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=700&q=80',desc:'Favorit warkop dengan topping lengkap.'},
  {name:'Nasi Goreng',cat:'makanan',price:16000,img:'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=700&q=80',desc:'Gurih, smoky, dan bikin kenyang.'},
  {name:'Roti Bakar',cat:'makanan',price:10000,img:'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=700&q=80',desc:'Roti renyah dengan isian favorit.'},
  {name:'Pisang Coklat',cat:'makanan',price:8000,img:'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=700&q=80',desc:'Manis legit untuk penutup malam.'},
  {name:'Kentang Goreng',cat:'makanan',price:10000,img:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=700&q=80',desc:'Renyah dan pas untuk sharing.'},
  {name:'Bakso Kuah',cat:'makanan',price:15000,img:'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=80',desc:'Hangat, gurih, dan cocok malam hari.'}
];

let cart = [];
const rupiah = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const grid = document.querySelector('#menuGrid');
const cartEl = document.querySelector('#cart');
const overlay = document.querySelector('#overlay');

function renderMenu(filter='all') {
  grid.innerHTML = menu.map((m,i) => `
    <article class="menu-card reveal ${filter!=='all'&&m.cat!==filter?'hidden':''}">
      <div class="menu-image-wrap"><img src="${m.img}" alt="${m.name}" loading="lazy"><span class="menu-tag">${m.cat === 'minuman' ? 'Minuman' : 'Makanan'}</span></div>
      <div class="menu-info"><h3>${m.name}</h3><p>${m.desc}</p><div class="menu-row"><span class="price">${rupiah(m.price)}</span><button class="add" onclick="addToCart(${i})" aria-label="Tambah ${m.name}">+</button></div></div>
    </article>`).join('');
  observeReveal();
}

function addToCart(i){
  const found=cart.find(x=>x.i===i);
  if(found) found.qty++;
  else cart.push({i,qty:1});
  renderCart();
  openCart();
  toast(`${menu[i].name} ditambahkan ke pesanan`);
}

function changeQty(i,d){
  const x=cart.find(x=>x.i===i); if(!x)return;
  x.qty += d;
  if(x.qty<=0) cart=cart.filter(x=>x.i!==i);
  renderCart();
}

function renderCart(){
  const el=document.querySelector('#cartItems');
  document.querySelector('#cartCount').textContent=cart.reduce((s,x)=>s+x.qty,0);
  const total=cart.reduce((s,x)=>s+menu[x.i].price*x.qty,0);
  if(!cart.length){el.innerHTML='<p class="empty">Belum ada pesanan.<br>Pilih menu favoritmu dulu.</p>';}
  else el.innerHTML=cart.map(x=>{const m=menu[x.i];return `<div class="cart-item"><img src="${m.img}" alt="${m.name}"><div><strong>${m.name}</strong><small>${rupiah(m.price)}</small></div><div class="qty"><button onclick="changeQty(${x.i},-1)">−</button><b>${x.qty}</b><button onclick="changeQty(${x.i},1)">+</button></div></div>`}).join('');
  document.querySelector('#cartTotal').textContent=rupiah(total);
}

function openCart(){cartEl.classList.add('open');overlay.classList.add('show');document.body.classList.add('cart-open')}
function closeCart(){cartEl.classList.remove('open');overlay.classList.remove('show');document.body.classList.remove('cart-open')}

function checkoutWhatsApp(){
  if(!cart.length){toast('Tambahkan menu terlebih dahulu');return;}
  const total=cart.reduce((s,x)=>s+menu[x.i].price*x.qty,0);
  const lines=cart.map((x,n)=>`${n+1}. ${menu[x.i].name} x${x.qty} — ${rupiah(menu[x.i].price*x.qty)}`);
  const message = `Halo Warkop Barockah Always 👋\n\nSaya ingin memesan:\n${lines.join('\n')}\n\nTotal: ${rupiah(total)}\n\nMohon konfirmasi pesanan saya. Terima kasih 🙏`;
  window.location.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function toast(message){
  let t=document.querySelector('.toast');
  if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t)}
  t.textContent=message;t.classList.add('show');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>t.classList.remove('show'),2200);
}

function observeReveal(){
  const items=document.querySelectorAll('.reveal:not(.observed)');
  if(!('IntersectionObserver' in window)){items.forEach(x=>x.classList.add('visible'));return}
  const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible','observed');io.unobserve(e.target)}}),{threshold:.08});
  items.forEach(x=>io.observe(x));
}

// Events

document.querySelector('#cartBtn').onclick=openCart;
document.querySelector('#closeCart').onclick=closeCart;
overlay.onclick=closeCart;
document.querySelector('#checkout').onclick=checkoutWhatsApp;
document.querySelector('#orderTop').onclick=e=>{e.preventDefault();document.querySelector('#menu').scrollIntoView({behavior:'smooth'})};
document.querySelector('#menuToggle').onclick=()=>document.querySelector('#nav').classList.toggle('open');
document.querySelectorAll('.nav a').forEach(a=>a.onclick=()=>document.querySelector('#nav').classList.remove('open'));
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderMenu(b.dataset.filter)});
document.querySelector('#copyNumber').onclick=async()=>{try{await navigator.clipboard.writeText('+62 877-1292-2471');toast('Nomor WhatsApp disalin')}catch{toast('+62 877-1292-2471')}};
document.querySelector('#waDirect').onclick=()=>{window.location.href=`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent('Halo Warkop Barockah Always, saya ingin bertanya tentang menu.')}`};

window.addEventListener('scroll',()=>{
  document.querySelector('.site-header').classList.toggle('scrolled',window.scrollY>20);
  const sections=[...document.querySelectorAll('main section[id]')];
  const y=window.scrollY+120;
  let current='top';
  sections.forEach(s=>{if(y>=s.offsetTop)current=s.id});
  document.querySelectorAll('.nav a').forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+current || (current==='top'&&a.getAttribute('href')==='#top')));
});

renderMenu();
renderCart();
observeReveal();
